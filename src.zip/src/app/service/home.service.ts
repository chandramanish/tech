import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

 public homeapi='http://vrok.in/taskeeper/list';  
 public industries='http://vrok.in/taskeeper/industries';
 public service='http://vrok.in/taskeeper/service';
 public staffing='http://vrok.in/taskeeper/staffing';
 public happening='http://vrok.in/taskeeper/happenings';
  constructor(private http:HttpClient) { }

  getdata(){
 return this.http.get(this.homeapi);
  }
getindustries(){

  return this.http.get(this.industries);
}
getservice(){
  return this.http.get(this.service);
}
getstaffing(){
  return this.http.get(this.staffing);
}
gethappening(){
  return this.http.get(this.happening);
}


}
