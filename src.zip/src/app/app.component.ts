import { Component } from '@angular/core';
import { HomeService } from './service/home.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent  {

  constructor( private slid:HomeService ){}


}

