import { BrowserModule } from '@angular/platform-browser';
import { NgModule ,NO_ERRORS_SCHEMA} from '@angular/core';
import { MDBBootstrapModule } from 'angular-bootstrap-md';

import  {HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { DashboardComponent } from './HOME/dashboard/dashboard.component';
import { MenuComponent } from './HOME/menu/menu.component';
import { IndustriesComponent } from './HOME/menu/industries/industries.component';
import { ServicesComponent } from './HOME/menu/services/services.component';
import { StaffingComponent } from './HOME/menu/staffing/staffing.component';
import { HappeningComponent } from './HOME/menu/happening/happening.component';
import { PortfolioComponent } from './HOME/menu/portfolio/portfolio.component';
import { BlogsComponent } from './HOME/menu/blogs/blogs.component';
import { ContactComponent } from './HOME/menu/contact/contact.component';
import { NavigateComponent } from './HOME/menu/navigate/navigate.component';
import { SliderComponent } from './HOME/slider/slider.component';
import { OurServicesComponent } from './HOME/our-services/our-services.component';
import { OurProfileTourComponent } from './HOME/our-profile-tour/our-profile-tour.component';
import { OurTechnologiesComponent } from './HOME/our-technologies/our-technologies.component';
import { KnowMoreComponent } from './HOME/know-more/know-more.component';
import { FootterComponent } from './HOME/footter/footter.component';
import { AppRoutingModule } from './app-routing.module';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    MenuComponent,
    IndustriesComponent,
    ServicesComponent,
    StaffingComponent,
    HappeningComponent,
    PortfolioComponent,
    BlogsComponent,
    ContactComponent,
    NavigateComponent,
    SliderComponent,
    OurServicesComponent,
    OurProfileTourComponent,
    OurTechnologiesComponent,
    KnowMoreComponent,
    FootterComponent
  ],
  imports: [
    BrowserModule,
    MDBBootstrapModule,
    HttpClientModule,
    AppRoutingModule
  ],
  schemas:[NO_ERRORS_SCHEMA],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
