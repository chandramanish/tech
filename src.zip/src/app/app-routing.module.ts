import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './HOME/dashboard/dashboard.component';
import { IndustriesComponent } from './HOME/menu/industries/industries.component';
import { ServicesComponent } from './HOME/menu/services/services.component';
import { StaffingComponent } from './HOME/menu/staffing/staffing.component';
import { HappeningComponent } from './HOME/menu/happening/happening.component';
import { PortfolioComponent } from './HOME/menu/portfolio/portfolio.component';
import { BlogsComponent } from './HOME/menu/blogs/blogs.component';
import { ContactComponent } from './HOME/menu/contact/contact.component';
import { NavigateComponent } from './HOME/menu/navigate/navigate.component';

const appRoute: Routes =[
{ path: '', component:DashboardComponent},
{ path:'industries', component:IndustriesComponent },
{ path:'services', component:ServicesComponent },
{ path:'staffing',component:StaffingComponent },
{ path:'happening',component:HappeningComponent},
{ path:'portfolio',component:PortfolioComponent },
{ path:'blogs', component:BlogsComponent},
{ path:'contact',component:ContactComponent},
{path:'nav',component:NavigateComponent}
]


@NgModule({
  declarations: [],
  imports: [
  
    RouterModule.forRoot(appRoute)
    ],
    exports:[RouterModule]
})
export class AppRoutingModule { }
