import { Component, OnInit } from '@angular/core';
import { HomeService } from 'src/app/service/home.service';

@Component({
  selector: 'app-know-more',
  templateUrl: './know-more.component.html',
  styleUrls: ['./know-more.component.scss']
})
export class KnowMoreComponent implements OnInit {

  public knowmore=[];

  constructor(private know:HomeService ) { }

  ngOnInit() {
    this.know.getdata().subscribe((data)=>{
      this.knowmore=data['Know more'];
    })
  }

}
