import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footter',
  templateUrl: './footter.component.html',
  styleUrls: ['./footter.component.scss']
})
export class FootterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
