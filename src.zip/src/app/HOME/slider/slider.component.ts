import { Component, OnInit } from '@angular/core';
import { HomeService } from 'src/app/service/home.service';

@Component({
  selector: 'app-slider',
  templateUrl: './slider.component.html',
  styleUrls: ['./slider.component.scss']
})
export class SliderComponent implements OnInit {

  slider=[];

  constructor(private slid:HomeService) { }

  ngOnInit() {
    this.slid.getdata().subscribe((data)=>{
      console.log("data >>>>",data);
      this.slider=data["Slider Data"];  
    })
  }

}
