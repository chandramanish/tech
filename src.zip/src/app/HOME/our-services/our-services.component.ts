import { Component, OnInit } from '@angular/core';
import { HomeService } from 'src/app/service/home.service';

@Component({
  selector: 'app-our-services',
  templateUrl: './our-services.component.html',
  styleUrls: ['./our-services.component.scss']
})
export class OurServicesComponent implements OnInit {
 
  public services=[]; 

  constructor(private service:HomeService ) { }

  ngOnInit() {
    this.service.getdata().subscribe((data)=>{
      this.services=data["Services"];
    })
  }

}
