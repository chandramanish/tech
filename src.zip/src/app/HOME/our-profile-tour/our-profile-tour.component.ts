import { Component, OnInit } from '@angular/core';
import { HomeService } from 'src/app/service/home.service';

@Component({
  selector: 'app-our-profile-tour',
  templateUrl: './our-profile-tour.component.html',
  styleUrls: ['./our-profile-tour.component.scss']
})
export class OurProfileTourComponent implements OnInit {

  public profile=[];
public videoUrl = [{'url':'http://google.com'},{'url':'http://gmail.com'}];
  constructor(private pro:HomeService ) { }

  ngOnInit() {
    this.pro.getdata().subscribe((data)=>{
      this.profile=data["Videos"];
      console.log("dataa video:::::", this.profile);
      
    })
  }

}
