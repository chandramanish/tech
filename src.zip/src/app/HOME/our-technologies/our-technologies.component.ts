import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-our-technologies',
  templateUrl: './our-technologies.component.html',
  styleUrls: ['./our-technologies.component.scss']
})
export class OurTechnologiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
