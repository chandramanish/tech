import { Component, OnInit } from '@angular/core';
import { HomeService } from 'src/app/service/home.service';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss']
})
export class ContactComponent implements OnInit {

   career:boolean=false;
   productEnquery:boolean=false;

  contactform:FormGroup;

  public slid=[];

  constructor(private con:HomeService) { }

  ngOnInit() {

    this.con.gethappening().subscribe((data)=>{
      console.log("data<<<<",data);
      this.slid=data['Slider Data'];
    })
  }

  Enquery(){
   this.career=true;
  }
  Service(){
    this.career=false;
  }
  product(){
    console.log("called");
    this.career=false;
    this.productEnquery=true;
  }
  onsubmit():void{
    console.log(this.contactform.value)
  }

}
