import { Component, OnInit } from '@angular/core';
import { HomeService } from 'src/app/service/home.service';

@Component({
  selector: 'app-happening',
  templateUrl: './happening.component.html',
  styleUrls: ['./happening.component.scss']
})
export class HappeningComponent implements OnInit {
 
  imagesWithHeading = [
    { img: "https://mdbootstrap.com/img/Mockups/Lightbox/Thumbnail/img%20(63).jpg", thumb: "https://mdbootstrap.com/img/Mockups/Lightbox/Thumbnail/img%20(63).jpg", description: "Image 1" },
    { img: "https://mdbootstrap.com/img/Mockups/Lightbox/Original/img%20(66).jpg", thumb: "https://mdbootstrap.com/img/Mockups/Lightbox/Thumbnail/img%20(66).jpg", description: "Image 2" },
    { img: "https://mdbootstrap.com/img/Mockups/Lightbox/Original/img%20(65).jpg", thumb: "https://mdbootstrap.com/img/Mockups/Lightbox/Thumbnail/img%20(65).jpg", description: "Image 3" },
    { img: "https://mdbootstrap.com/img/Mockups/Lightbox/Original/img%20(67).jpg", thumb: "https://mdbootstrap.com/img/Mockups/Lightbox/Thumbnail/img%20(67).jpg", description: "Image 4" },
    { img: "https://mdbootstrap.com/img/Mockups/Lightbox/Original/img%20(68).jpg", thumb: "https://mdbootstrap.com/img/Mockups/Lightbox/Thumbnail/img%20(68).jpg", description: "Image 5" },
    { img: "https://mdbootstrap.com/img/Mockups/Lightbox/Original/img%20(64).jpg", thumb: "https://mdbootstrap.com/img/Mockups/Lightbox/Thumbnail/img%20(64).jpg", description: "Image 6" },
    { img: "https://mdbootstrap.com/img/Mockups/Lightbox/Original/img%20(69).jpg", thumb: "https://mdbootstrap.com/img/Mockups/Lightbox/Thumbnail/img%20(69).jpg", description: "Image 7" },
    { img: "https://mdbootstrap.com/img/Mockups/Lightbox/Original/img%20(59).jpg", thumb: "https://mdbootstrap.com/img/Mockups/Lightbox/Thumbnail/img%20(59).jpg", description: "Image 8" },
    { img: "https://mdbootstrap.com/img/Mockups/Lightbox/Original/img%20(70).jpg", thumb: "https://mdbootstrap.com/img/Mockups/Lightbox/Thumbnail/img%20(70).jpg", description: "Image 9" }
];
 
  public happen=[];
  public gal=[];
  public gal2=[];
  public gal3=[];
  public gal4=[];
  public gal5=[];
  public gal6=[];

  constructor(private happ:HomeService) { }

  ngOnInit() {
    this.happ.gethappening().subscribe((data)=>{
      console.log('data....>',data);
      this.happen=data['Slider Data'];
      this.gal=data['Gellery1'];
      this.gal2=data['Gellery2'];
      this.gal3=data['Gellery3'];
      this.gal4=data['Gellery4'];
      this.gal5=data['Gellery5'];
      this.gal6=data['Gellery6'];
    })
  }
 

}
