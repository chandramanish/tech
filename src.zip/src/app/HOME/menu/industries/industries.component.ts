import { Component, OnInit } from '@angular/core';
import { HomeService } from 'src/app/service/home.service';

@Component({
  selector: 'app-industries',
  templateUrl: './industries.component.html',
  styleUrls: ['./industries.component.scss']
})
export class IndustriesComponent implements OnInit {

  public industry=[];
  public indust=[];

  constructor(private indu:HomeService) { }

  ngOnInit() {
    this.indu.getindustries().subscribe((data)=>{
      console.log('data###',data);
      this.industry=data['Slider Data'];
      this.indust=data['Our Indusries']
    })
  }

}
