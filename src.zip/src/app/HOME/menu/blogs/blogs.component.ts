import { Component, OnInit } from '@angular/core';
import { HomeService } from 'src/app/service/home.service';

@Component({
  selector: 'app-blogs',
  templateUrl: './blogs.component.html',
  styleUrls: ['./blogs.component.scss']
})
export class BlogsComponent implements OnInit {

  public blog=[];

  constructor(private blogs:HomeService) { }

  ngOnInit() {
    this.blogs.getservice().subscribe((data)=>{
      console.log("data ****",data);
      this.blog=data['Blogs'];

    })
  }

}
