import { Component, OnInit } from '@angular/core';
import { HomeService } from 'src/app/service/home.service';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.scss']
})
export class ServicesComponent implements OnInit {

  public service=[];
  public blog = [];

  constructor(private ser:HomeService) { }

  ngOnInit() {
    this.ser.getservice().subscribe((data)=>{
      console.log("data==>",data);
      this.service=data['Slider Data'];
      this.blog=data['Blogs'];
    })
  }

}
