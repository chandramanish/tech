import { Component, OnInit } from '@angular/core';
import { HomeService } from 'src/app/service/home.service';

@Component({
  selector: 'app-staffing',
  templateUrl: './staffing.component.html',
  styleUrls: ['./staffing.component.scss']
})
export class StaffingComponent implements OnInit {

  public staffing=[];
  public blog=[];

  constructor(private staff:HomeService) { }

  ngOnInit() {
  this.staff.getstaffing().subscribe((data)=>{
    console.log("data-->",data);
    this.staffing=data['Slider Data'];
    this.blog=data['Blogs'];
  })
  }

}
